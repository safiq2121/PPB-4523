package com.example.mylbs;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.mylbs.databinding.ActivityMapsBinding;

import java.sql.Array;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, AdapterView.OnItemClickListener {

    private GoogleMap mMap;
    public static final String namapulau[]={"PILIH PULAU","sumatra","jawa","kalimantan","sulasewsi","bali","ntb","ntt"};
    Spinner spinner;
    private ActivityMapsBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        spinner=findViewById(R.id.pilihpulau);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,namapulau);
        spinner.setAdapter(adapter);
        spinner.setOnItemClickListener(this);


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        double lati,longi;

        switch (position)
        {
            case 0:
            case 1:
                mMap.clear();
                // Add a marker in Sydney and move the camera
                LatLng aceh = new LatLng(4.0432595, 94.4035277);
                mMap.addMarker(new MarkerOptions().position(aceh).title("nad"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(aceh));

                LatLng mdn = new LatLng(3.6426183, 98.5294036);
                mMap.addMarker(new MarkerOptions().position(aceh).title("mdn"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(aceh));

                LatLng pdg = new LatLng(-0.9342375, 100.2511799);
                mMap.addMarker(new MarkerOptions().position(pdg).title("pdg"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(pdg));

                LatLng plb = new LatLng(-2.9547949, 104.6929232);
                mMap.addMarker(new MarkerOptions().position(plb).title("plb"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(plb));
                break;
            case 2:
            case 3:
            case 4:
            default:
                Toast.makeText(this, "Pilihan tidak ada", Toast.LENGTH_SHORT).show();
        }
    }
}